# Baithut – Finish Line Checklist (End-to-End)

## 0) Tools you need
- Flutter SDK (latest stable)
- Firebase CLI (`npm i -g firebase-tools`)
- Node 18+
- Stripe account (test mode first)
- (Optional) Shippo account for labels

## 1) Create native folders & get deps
```bash
flutter create .
flutter pub get
```

## 2) Initialize Firebase
```bash
firebase login
firebase init
# Enable: Firestore, Storage, Functions (JavaScript), Hosting (optional for return URLs)
```
Generate platform config for the app:
```bash
dart run flutterfire_cli configure
```
This writes `lib/services/firebase_options.dart` and auto-wires `main.dart` once you uncomment the line.

## 3) Set security rules
```bash
firebase deploy --only firestore:rules
```

## 4) Stripe + platform fees + webhook + (optional) Shippo
```bash
cd functions
npm i
firebase functions:config:set   stripe.secret_key="sk_test_..."   stripe.wh_secret="whsec_..."   platform.buyer_fee_bps="1000"   platform.seller_fee_bps="1000"   app.url="https://<your-project>.web.app"   shippo.key="shippo_test_..."   # optional
firebase deploy --only functions
```
Stripe Webhook (Dashboard → Webhooks):
- URL: `https://us-central1-<project>.cloudfunctions.net/stripeWebhook`
- Event: `account.updated`

## 5) Required build flags when running
```bash
flutter run   --dart-define=STRIPE_PUBLISHABLE_KEY=pk_test_...   --dart-define=CREATE_PI_URL=https://us-central1-<project>.cloudfunctions.net/createPaymentIntent   --dart-define=HTTPS_FUNCTIONS_BASE=https://us-central1-<project>.cloudfunctions.net
```

## 6) iOS / Android platform tweaks
- **iOS**: In `ios/Runner/Info.plist`, add URL schemes for Stripe + Google Sign-In and allow arbitrary loads if testing on localhost.
- **Android**: In `android/app/src/main/AndroidManifest.xml`, ensure INTERNET permission and any Stripe redirect activities are present (PaymentSheet requires no special scheme, but Google Sign-In does).

## 7) Test flow (Stripe test mode)
1. Create a user → **Profile → Become a Seller** → finish Express onboarding.
2. Confirm `users/{uid}` shows `stripeAccountId`, and webhook syncs `payoutsEnabled/chargesEnabled`.
3. Create a **listing** (make sure the seller is the onboarded account).
4. As another user, **Buy Now** → PaymentSheet → pay with `4242 4242 4242 4242`.
5. Check `transactions` doc created with `status: "paid"`.
6. Admin icon (top-right) → **Verify & Release** → payout should transfer `(base − 10%)` to seller.
7. `transactions/{id}` status becomes `paid_out`.
8. (Optional) Call `createShippingLabel` with to/from/parcel → confirm label URL.

## 8) Production launch
- Switch Stripe keys to **live**.
- Add Firebase App Check / auth middleware to protect HTTPS endpoints.
- Migrate client-side filters to Firestore queries + indexes.
- Prepare **App Store** / **Play Store** listings, privacy policy, and terms.
- Monitor Functions logs for Stripe failures.

## 9) Nice-to-haves (after launch)
- Listing reservation + auto-cancel
- Buyer/Seller chat per transaction
- Dispute UI (calls `refundPaymentIntent`)
- Email receipts (Functions + SendGrid/Mailgun)
