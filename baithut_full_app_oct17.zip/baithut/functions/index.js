const functions = require('firebase-functions');
const admin = require('firebase-admin');
const Stripe = require('stripe');

admin.initializeApp();
const db = admin.firestore();

// Config (set via firebase functions:config:set ... )
// stripe.secret_key, platform.buyer_fee_bps, platform.seller_fee_bps, app.url, shippo.key (optional), stripe.wh_secret (optional)
const stripe = new Stripe(functions.config().stripe.secret_key, { apiVersion: '2024-06-20' });
const BUYER_FEE_BPS = parseInt(functions.config().platform?.buyer_fee_bps || '1000', 10); // 10%
const SELLER_FEE_BPS = parseInt(functions.config().platform?.seller_fee_bps || '1000', 10); // 10%
const APP_URL = functions.config().app?.url || 'https://example.com';

// ============= HELPERS =============
function addBps(amount, bps) {
  return amount + Math.floor((amount * bps) / 10000);
}
function subBps(amount, bps) {
  return amount - Math.floor((amount * bps) / 10000);
}

// ============= PAYMENTS =============

// Create a PaymentIntent for the BUYER: charge = base + buyer fee
exports.createPaymentIntent = functions.https.onRequest(async (req, res) => {
  try {
    const { baseAmountCents, currency, listingId, buyerUid, sellerUid } = req.body;
    if (!baseAmountCents || !currency) return res.status(400).send('baseAmountCents and currency required');
    const totalCharge = addBps(baseAmountCents, BUYER_FEE_BPS);
    const pi = await stripe.paymentIntents.create({
      amount: totalCharge,
      currency,
      capture_method: 'automatic',
      automatic_payment_methods: { enabled: true },
      metadata: {
        listingId: listingId || '',
        buyerUid: buyerUid || '',
        sellerUid: sellerUid || '',
        baseAmountCents: String(baseAmountCents),
        buyerFeeBps: String(BUYER_FEE_BPS),
        sellerFeeBps: String(SELLER_FEE_BPS),
      }
    });
    return res.json({ clientSecret: pi.client_secret, id: pi.id, totalCharge });
  } catch (e) {
    console.error(e);
    return res.status(500).send(e.message);
  }
});

// After verification, send payout to seller (base - seller fee)
exports.releasePayout = functions.https.onCall(async (data, context) => {
  const { sellerUid, baseAmountCents, listingId, transactionId } = data || {};
  if (!sellerUid || !baseAmountCents) throw new functions.https.HttpsError('invalid-argument', 'sellerUid and baseAmountCents required');
  const userSnap = await db.collection('users').doc(sellerUid).get();
  if (!userSnap.exists) throw new functions.https.HttpsError('not-found', 'Seller not found');
  const acct = userSnap.get('stripeAccountId');
  const payoutsEnabled = userSnap.get('payoutsEnabled');
  if (!acct) throw new functions.https.HttpsError('failed-precondition', 'Seller not onboarded to Stripe Connect');
  if (!payoutsEnabled) throw new functions.https.HttpsError('failed-precondition', 'Seller payouts not enabled yet');
  const transferAmount = subBps(baseAmountCents, SELLER_FEE_BPS);
  if (transferAmount <= 0) throw new functions.https.HttpsError('failed-precondition', 'Transfer amount must be positive');
  const transfer = await stripe.transfers.create({
    amount: transferAmount,
    currency: 'usd',
    destination: acct,
    description: listingId ? `Baithut payout for ${listingId}` : 'Baithut payout',
    metadata: { listingId: listingId || '', transactionId: transactionId || '' },
  });
  await db.collection('payouts').add({
    sellerUid, listingId: listingId || null, transactionId: transactionId || null,
    baseAmountCents, sellerFeeBps: SELLER_FEE_BPS, transferAmount, stripeTransferId: transfer.id,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  return { ok: true, transferId: transfer.id, transferAmount };
});

// Refunds / disputes (admin-driven for MVP)
exports.refundPaymentIntent = functions.https.onCall(async (data, context) => {
  const { paymentIntentId, amount } = data || {};
  if (!paymentIntentId) throw new functions.https.HttpsError('invalid-argument', 'paymentIntentId required');
  const refund = await stripe.refunds.create({
    payment_intent: paymentIntentId,
    amount: amount || undefined, // if omitted, full refund
  });
  return { ok: true, refundId: refund.id, status: refund.status };
});

// ============= CONNECT (Express) =============
exports.createOrGetAccount = functions.https.onRequest(async (req, res) => {
  try {
    const uid = req.get('x-test-uid') || req.query.uid || 'demo-user';
    const userRef = db.collection('users').doc(uid);
    const userDoc = await userRef.get();
    let acct = userDoc.exists ? userDoc.get('stripeAccountId') : null;
    if (!acct) {
      const account = await stripe.accounts.create({
        type: 'express',
        capabilities: { card_payments: { requested: true }, transfers: { requested: true } },
        business_type: 'individual',
      });
      acct = account.id;
      await userRef.set({ stripeAccountId: acct }, { merge: true });
    }
    return res.json({ accountId: acct });
  } catch (e) {
    console.error(e);
    return res.status(500).send(e.message);
  }
});

exports.createAccountLink = functions.https.onRequest(async (req, res) => {
  try {
    const uid = req.get('x-test-uid') || req.query.uid || 'demo-user';
    const userDoc = await db.collection('users').doc(uid).get();
    const acct = userDoc.get('stripeAccountId');
    if (!acct) return res.status(400).send('No connected account; call createOrGetAccount first.');
    const al = await stripe.accountLinks.create({
      account: acct,
      refresh_url: `${APP_URL}/onboarding/refresh`,
      return_url: `${APP_URL}/onboarding/return`,
      type: 'account_onboarding',
    });
    return res.json({ url: al.url });
  } catch (e) {
    console.error(e);
    return res.status(500).send(e.message);
  }
});

exports.stripeWebhook = functions.https.onRequest(async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const whSecret = functions.config().stripe?.wh_secret;
  let event;
  try {
    if (whSecret) {
      event = stripe.webhooks.constructEvent(req.rawBody, sig, whSecret);
    } else {
      event = req.body;
    }
  } catch (err) {
    console.error(err);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  try {
    switch (event.type) {
      case 'account.updated': {
        const acct = event.data.object;
        const acctId = acct.id;
        const q = await db.collection('users').where('stripeAccountId', '==', acctId).limit(1).get();
        if (!q.empty) {
          const ref = q.docs[0].ref;
          await ref.set({
            payoutsEnabled: !!acct.payouts_enabled,
            chargesEnabled: !!acct.charges_enabled,
            detailsSubmitted: !!acct.details_submitted,
            lastStripeSync: admin.firestore.FieldValue.serverTimestamp(),
          }, { merge: true });
        }
        break;
      }
      default: break;
    }
    res.json({ received: true });
  } catch (e) {
    console.error(e);
    res.status(500).send('Webhook handler error');
  }
});

// ============= SHIPPING (stub with Shippo) =============
let shippo = null;
try {
  const Shippo = require('shippo')(functions.config().shippo?.key || '');
  shippo = Shippo;
} catch (e) {
  // Shippo not configured; endpoints will error if called without key.
}

exports.createShippingLabel = functions.https.onCall(async (data, context) => {
  if (!shippo) throw new functions.https.HttpsError('failed-precondition', 'Shippo key not configured');
  const { to, from, parcel } = data || {};
  if (!to || !from || !parcel) throw new functions.https.HttpsError('invalid-argument', 'to, from, parcel required');
  // Minimal example; in production, select a specific rate by ID after returning available rates
  const shipment = await shippo.shipment.create({ address_to: to, address_from: from, parcels: [parcel] });
  const rates = shipment.rates || [];
  if (!rates.length) throw new functions.https.HttpsError('failed-precondition', 'No rates found');
  const txn = await shippo.transaction.create({ rate: rates[0].object_id, label_file_type: 'PDF' });
  if (txn.status !== 'SUCCESS') throw new functions.https.HttpsError('internal', 'Label purchase failed');
  return { labelUrl: txn.label_url, trackingNumber: txn.tracking_number };
});
