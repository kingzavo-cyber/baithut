# Stripe Connect Payouts (Express) – Setup

## 0) Prereqs
- Stripe account
- Firebase project with Functions enabled
- Your deployed Hosting URL (used for onboarding return/refresh)

## 1) Configure Functions
```bash
cd functions
npm i
firebase functions:config:set   stripe.secret_key="sk_test_..."   platform.fee_bps="1000"   app.url="https://<your-project>.web.app"
firebase deploy --only functions
```

## 2) Secure your HTTPS endpoints
- In production, protect `createOrGetAccount` and `createAccountLink` with Firebase Auth (ID token check).
- For quick testing, you can pass a header `x-test-uid: <uid>` and create a `users/<uid>` doc.

## 3) Webhook (optional but recommended)
Create a webhook endpoint in Stripe:
- URL: `https://us-central1-<project>.cloudfunctions.net/stripeWebhook`
- Events: `account.updated`
- Copy the **Webhook Secret** and set it:
```bash
firebase functions:config:set stripe.wh_secret="whsec_..."
firebase deploy --only functions
```

## 4) Client build flags
When running the app:
```bash
flutter run   --dart-define=STRIPE_PUBLISHABLE_KEY=pk_test_...   --dart-define=CREATE_PI_URL=https://us-central1-<project>.cloudfunctions.net/createPaymentIntent   --dart-define=HTTPS_FUNCTIONS_BASE=https://us-central1-<project>.cloudfunctions.net
```

## 5) Onboarding flow
1. User goes to **Profile → Become a Seller (Stripe Onboarding)**.
2. App calls:
   - `createOrGetAccount`
   - `createAccountLink` and opens the onboarding URL
3. After onboarding, Stripe redirects to your Hosting return URL.

## 6) Releasing payouts (after verification)
- When an item is verified, call the callable function `releasePayout` with:
  ```json
  { "sellerUid": "<uid>", "amount": 12345, "listingId": "abc", "transactionId": "tx123" }
  ```
- This will create a **Stripe Transfer** to the seller’s connected account and log it in `payouts` collection.

## 7) Notes
- This is **separate charges and transfers**. Funds are charged to the platform and later **transferred** after verification (escrow-like behavior).
- For instant split at charge time, you can use **destination charges** with `transfer_data.destination`, but that is not escrow.
- Ensure your platform balance has **available funds** (test mode settles quickly; live depends on card networks).


## Updated fees: buyer + seller (10% each by default)
Configure both fees (in basis points):
```bash
firebase functions:config:set platform.buyer_fee_bps="1000" platform.seller_fee_bps="1000"
firebase deploy --only functions
```
- Buyer is charged: `base + 10%`
- Seller receives: `base - 10%` (rest is your platform revenue)

## Refunds
Call `refundPaymentIntent` (callable) with `paymentIntentId` and optional `amount` (cents).

## Shipping (Shippo stub)
```bash
firebase functions:config:set shippo.key="shippo_test_xxx"
firebase deploy --only functions
```
Use callable `createShippingLabel({ to, from, parcel })`.
