# Baithut (MVP) – Flutter + Firebase + Stripe

A mobile-first marketplace for buy/sell/trade of swimbaits with escrow-style payments and manual verification.

## Stack
- Flutter (Dart, null-safety)
- Firebase: Auth, Firestore, Storage, Cloud Functions
- Stripe: Payments via `flutter_stripe` and Firebase Functions (escrow flow)

## Quick Start

> **Prereqs**: Flutter SDK, Firebase CLI, Node 18+, a Stripe account

### 1) Scaffold native folders
```bash
flutter create .
```

### 2) Configure Firebase
```bash
firebase login
firebase init
# enable Firestore, Functions, Storage; choose JavaScript for Functions
```
Copy your Firebase config into `lib/services/firebase_options.dart` using:
```bash
dart run flutterfire_cli configure
```

### 3) Stripe setup
- In Stripe Dashboard, create a test API key.
- Set env vars for Cloud Functions:
```bash
cd functions
npm i
firebase functions:config:set stripe.secret_key="sk_test_..." platform.fee_bps="1000"
# 1000 bps = 10% platform fee
firebase deploy --only functions
```
- In Flutter, set the publishable key (see `stripe_service.dart`).

### 4) Install Flutter deps
```bash
flutter pub get
```

### 5) Add iOS/Android configuration
- **iOS**: add URL schemes for Stripe and Google Sign-In in `ios/Runner/Info.plist`.
- **Android**: update `android/app/src/main/AndroidManifest.xml` for internet, Stripe callbacks, and Google sign-in.

### 6) Firestore Rules
Deploy the baseline rules:
```bash
firebase deploy --only firestore:rules
```

### 7) Run
```bash
flutter run
```

## Escrow Flow
1. Buyer taps **Buy Now** → client creates a PaymentIntent via Cloud Function.
2. Funds captured to platform (separate balance) while status = `pending`.
3. Admin verifies item → Function releases payout to seller using Stripe Connect (or manual for MVP).
4. Platform fee automatically deducted (bps env var).

## Notes
- This MVP uses email + Google sign-in.
- Verification is manual via Firestore flags (`listings/{id}.verified`). You can later build a simple admin web UI or use Firebase Console for toggling.

