import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../models/listing.dart';
import 'checkout_screen.dart';

class ListingDetailScreen extends StatefulWidget {
  final Listing listing;
  const ListingDetailScreen({super.key, required this.listing});

  @override
  State<ListingDetailScreen> createState() => _ListingDetailScreenState();
}

class _ListingDetailScreenState extends State<ListingDetailScreen> {
  bool _sellerPayoutsEnabled = false;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadSellerStatus();
  }

  Future<void> _loadSellerStatus() async {
    try {
      final doc = await FirebaseFirestore.instance.collection('users').doc(widget.listing.sellerId).get();
      setState(() {
        _sellerPayoutsEnabled = (doc.data()?['payoutsEnabled'] ?? false) as bool;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final basePrice = (widget.listing.priceCents / 100).toStringAsFixed(2);
    return Scaffold(
      appBar: AppBar(title: Text(widget.listing.title)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Chip(label: Text(widget.listing.brand)),
                const SizedBox(width: 8),
                Chip(label: Text(widget.listing.condition)),
                if (widget.listing.verified) const Padding(
                  padding: EdgeInsets.only(left: 8.0),
                  child: Icon(Icons.verified, size: 18),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text('Base Price: \$$basePrice', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Note: A 10% buyer fee is added at checkout.'),
            const SizedBox(height: 24),
            if (_loading) const Center(child: CircularProgressIndicator()),
            if (!_loading)
              ElevatedButton.icon(
                icon: const Icon(Icons.shopping_cart_checkout),
                label: Text(_sellerPayoutsEnabled ? 'Buy Now' : 'Seller not ready (payouts disabled)'),
                onPressed: _sellerPayoutsEnabled ? () {
                  final buyerUid = FirebaseAuth.instance.currentUser?.uid;
                  Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutScreen(listing: widget.listing, buyerUid: buyerUid)));
                } : null,
              ),
          ],
        ),
      ),
    );
  }
}
