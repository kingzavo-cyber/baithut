import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/connect_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _busy = false;
  DocumentSnapshot<Map<String, dynamic>>? _userDoc;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    setState(() => _userDoc = doc);
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final data = _userDoc?.data();
    final payoutsEnabled = (data?['payoutsEnabled'] ?? false) as bool;
    final chargesEnabled = (data?['chargesEnabled'] ?? false) as bool;

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(user?.email ?? 'Unknown'),
            const SizedBox(height: 12),
            Row(children: [
              Chip(label: Text('Payouts: ${payoutsEnabled ? "Enabled" : "Disabled"}')),
              const SizedBox(width: 8),
              Chip(label: Text('Charges: ${chargesEnabled ? "Enabled" : "Disabled"}')),
            ]),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _busy ? null : () async {
                setState(() => _busy = true);
                try {
                  const baseUrl = String.fromEnvironment('HTTPS_FUNCTIONS_BASE', defaultValue: '');
                  if (baseUrl.isEmpty) {
                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Set HTTPS_FUNCTIONS_BASE dart-define.')));
                    return;
                  }
                  final svc = ConnectService(baseUrl);
                  await svc.createOrGetAccount();
                  final url = await svc.createAccountLink();
                  if (!await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)) {
                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open onboarding link.')));
                  }
                } catch (e) {
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
                } finally {
                  if (mounted) {
                    await _load();
                    setState(() => _busy = false);
                  }
                }
              },
              child: const Text('Become a Seller (Stripe Onboarding)'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
              },
              child: const Text('Sign Out'),
            )
          ],
        ),
      ),
    );
  }
}
