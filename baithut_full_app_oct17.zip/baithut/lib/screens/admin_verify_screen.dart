import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:cloud_functions/cloud_functions.dart';

class AdminVerifyScreen extends StatefulWidget {
  const AdminVerifyScreen({super.key});

  @override
  State<AdminVerifyScreen> createState() => _AdminVerifyScreenState();
}

class _AdminVerifyScreenState extends State<AdminVerifyScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin – Verify & Payout')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance.collection('listings').where('verified', isEqualTo: false).snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('No unverified listings.'));
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i];
              final priceCents = (d.data()['priceCents'] as num?)?.toInt() ?? 0;
              return ListTile(
                title: Text(d.data()['title'] ?? ''),
                subtitle: Text('Seller: ${d.data()['sellerId']} • \$${(priceCents/100).toStringAsFixed(2)}'),
                trailing: ElevatedButton(
                  child: const Text('Verify & Release'),
                  onPressed: () async {
                    try {
                      // Find latest transaction for this listing
                      final txQuery = await FirebaseFirestore.instance.collection('transactions')
                        .where('listingId', isEqualTo: d.id)
                        .orderBy('createdAt', descending: true)
                        .limit(1).get();
                      if (txQuery.docs.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No transaction found for this listing.')));
                        return;
                      }
                      final txDoc = txQuery.docs.first;
                      // Verify listing & mark sold
                      await d.reference.update({'verified': true, 'sold': true});
                      // Release payout
                      final callable = FirebaseFunctions.instance.httpsCallable('releasePayout');
                      await callable.call({
                        'sellerUid': d.data()['sellerId'],
                        'baseAmountCents': priceCents,
                        'listingId': d.id,
                        'transactionId': txDoc.id,
                      });
                      // Update transaction status
                      await txDoc.reference.set({
                        'status': 'paid_out',
                        'payoutAt': FieldValue.serverTimestamp(),
                      }, SetOptions(merge: true));
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Verified & payout released.')));
                      }
                    } catch (e) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
                      }
                    }
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
