import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import '../models/listing.dart';
import '../services/transaction_service.dart';

class CheckoutScreen extends StatefulWidget {
  final Listing listing;
  final String? buyerUid;
  const CheckoutScreen({super.key, required this.listing, this.buyerUid});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  bool _busy = false;
  String? _clientSecret;
  int? _totalCharge;
  String? _paymentIntentId;

  @override
  Widget build(BuildContext context) {
    final base = widget.listing.priceCents;
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.listing.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('Base: \$${(base / 100).toStringAsFixed(2)}'),
            if (_totalCharge != null) Text('Total (with 10% buyer fee): \$${((_totalCharge ?? 0) / 100).toStringAsFixed(2)}'),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _busy ? null : _createPaymentIntent,
              child: const Text('1) Create Payment Intent'),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: (_busy || _clientSecret == null) ? null : _presentPaymentSheet,
              child: const Text('2) Pay with PaymentSheet'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _createPaymentIntent() async {
    setState(() => _busy = true);
    try {
      const functionUrl = String.fromEnvironment('CREATE_PI_URL', defaultValue: '');
      if (functionUrl.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Set CREATE_PI_URL env var at build time.')));
        return;
      }
      final buyerUid = widget.buyerUid ?? FirebaseAuth.instance.currentUser?.uid;
      final res = await http.post(Uri.parse(functionUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'baseAmountCents': widget.listing.priceCents,
          'currency': 'usd',
          'listingId': widget.listing.id,
          'buyerUid': buyerUid,
          'sellerUid': widget.listing.sellerId,
        }));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() {
          _clientSecret = data['clientSecret'];
          _paymentIntentId = data['id'];
          _totalCharge = data['totalCharge'];
        });
        await Stripe.instance.initPaymentSheet(paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: _clientSecret!,
          merchantDisplayName: 'Baithut',
          allowsDelayedPaymentMethods: true,
        ));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PaymentSheet ready.')));
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: ${res.body}')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _presentPaymentSheet() async {
    setState(() => _busy = true);
    try {
      await Stripe.instance.presentPaymentSheet();
      // Success → record transaction
      final buyerUid = widget.buyerUid ?? FirebaseAuth.instance.currentUser?.uid ?? 'unknown';
      final txId = await TransactionService.create(
        buyerId: buyerUid,
        sellerId: widget.listing.sellerId,
        listingId: widget.listing.id ?? '',
        paymentIntentId: _paymentIntentId ?? '',
        baseAmountCents: widget.listing.priceCents,
        totalChargeCents: _totalCharge ?? widget.listing.priceCents,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Payment successful. Transaction: $txId')));
        Navigator.pop(context); // back to listing
      }
    } on StripeException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Stripe error: ${e.error.localizedMessage}')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Payment error: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}
