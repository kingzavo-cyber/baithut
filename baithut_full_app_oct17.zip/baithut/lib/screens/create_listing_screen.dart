import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/listing.dart';
import '../services/firestore_service.dart';
import '../services/storage_service.dart';

class CreateListingScreen extends StatefulWidget {
  const CreateListingScreen({super.key});

  @override
  State<CreateListingScreen> createState() => _CreateListingScreenState();
}

class _CreateListingScreenState extends State<CreateListingScreen> {
  final _title = TextEditingController();
  final _brand = TextEditingController();
  final _price = TextEditingController();
  String _condition = 'Used';
  List<File> _images = [];
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Listing')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _title, decoration: const InputDecoration(labelText: 'Title')),
            TextField(controller: _brand, decoration: const InputDecoration(labelText: 'Brand')),
            DropdownButtonFormField<String>(
              value: _condition,
              items: const [
                DropdownMenuItem(value: 'New', child: Text('New')),
                DropdownMenuItem(value: 'Like New', child: Text('Like New')),
                DropdownMenuItem(value: 'Used', child: Text('Used')),
              ],
              onChanged: (v) => setState(() => _condition = v ?? 'Used'),
              decoration: const InputDecoration(labelText: 'Condition'),
            ),
            TextField(controller: _price, decoration: const InputDecoration(labelText: 'Price (USD)'), keyboardType: TextInputType.number),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                for (final f in _images) Image.file(f, width: 80, height: 80, fit: BoxFit.cover),
                IconButton(
                  icon: const Icon(Icons.add_a_photo),
                  onPressed: () async {
                    final picker = ImagePicker();
                    final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
                    if (x != null) setState(() => _images.add(File(x.path)));
                  },
                )
              ],
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _busy ? null : () async {
                setState(() => _busy = true);
                try {
                  final uid = FirebaseAuth.instance.currentUser!.uid;
                  final listing = Listing(
                    title: _title.text.trim(),
                    brand: _brand.text.trim(),
                    condition: _condition,
                    priceCents: ((double.tryParse(_price.text.trim()) ?? 0) * 100).round(),
                    sellerId: uid,
                    images: [],
                  );
                  await FirestoreService.createListing(listing);
                  // In a real flow, you'd get the doc id first; simplified for MVP upload by title.
                  // You can later update with upload URLs.
                  if (mounted) Navigator.pop(context);
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to create listing: $e')));
                } finally {
                  if (mounted) setState(() => _busy = false);
                }
              },
              child: const Text('Publish Listing'),
            )
          ],
        ),
      ),
    );
  }
}
