import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firestore_service.dart';
import '../models/listing.dart';
import 'listing_detail_screen.dart';
import 'create_listing_screen.dart';
import 'profile_screen.dart';
import 'admin_verify_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _query = '';
  String _brand = '';
  String _condition = 'All';
  double? _minPrice;
  double? _maxPrice;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Baithut'),
        actions: [
          IconButton(
            icon: const Icon(Icons.verified_user),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminVerifyScreen())),
            tooltip: 'Admin',
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search title/brand...'),
                    onChanged: (v) => setState(() => _query = v.trim()),
                  ),
                ),
                const SizedBox(width: 8),
                DropdownButton<String>(
                  value: _condition,
                  items: const [
                    DropdownMenuItem(value: 'All', child: Text('All')),
                    DropdownMenuItem(value: 'New', child: Text('New')),
                    DropdownMenuItem(value: 'Like New', child: Text('Like New')),
                    DropdownMenuItem(value: 'Used', child: Text('Used')),
                  ],
                  onChanged: (v) => setState(() => _condition = v ?? 'All'),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              children: [
                Flexible(child: TextField(decoration: const InputDecoration(labelText: 'Brand'), onChanged: (v) => setState(() => _brand = v.trim()))),
                const SizedBox(width: 8),
                Flexible(child: TextField(decoration: const InputDecoration(labelText: 'Min $'), keyboardType: TextInputType.number, onChanged: (v) => setState(() => _minPrice = double.tryParse(v))),
                const SizedBox(width: 8),
                Flexible(child: TextField(decoration: const InputDecoration(labelText: 'Max $'), keyboardType: TextInputType.number, onChanged: (v) => setState(() => _maxPrice = double.tryParse(v))),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<List<Listing>>(
              stream: FirestoreService.streamListings(),
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                var listings = snap.data!;
                // client-side filters (MVP); can convert to Firestore queries later
                listings = listings.where((l) {
                  final price = l.priceCents / 100.0;
                  final matchesQuery = _query.isEmpty || l.title.toLowerCase().contains(_query.toLowerCase()) || l.brand.toLowerCase().contains(_query.toLowerCase());
                  final matchesBrand = _brand.isEmpty || l.brand.toLowerCase().contains(_brand.toLowerCase());
                  final matchesCond = _condition == 'All' || l.condition == _condition;
                  final matchesMin = _minPrice == null || price >= _minPrice!;
                  final matchesMax = _maxPrice == null || price <= _maxPrice!;
                  return matchesQuery && matchesBrand && matchesCond && matchesMin && matchesMax;
                }).toList();
                if (listings.isEmpty) return const Center(child: Text('Nothing matches your filters.'));
                return ListView.builder(
                  itemCount: listings.length,
                  itemBuilder: (_, i) => ListTile(
                    title: Text(listings[i].title),
                    subtitle: Text('${listings[i].brand} • ${listings[i].condition}'),
                    trailing: Text('\$${(listings[i].priceCents / 100).toStringAsFixed(2)}'),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ListingDetailScreen(listing: listings[i]))),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          children: [
            IconButton(icon: const Icon(Icons.add_box_outlined), onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateListingScreen()));
            }),
            const Spacer(),
            IconButton(icon: const Icon(Icons.person_outline), onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()));
            }),
          ],
        ),
      ),
    );
  }
}
