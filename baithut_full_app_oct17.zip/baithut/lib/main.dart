import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'services/stripe_service.dart';

// TODO: generate this with flutterfire_cli
// import 'services/firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    // options: DefaultFirebaseOptions.currentPlatform,
  );
  StripeService.init(); // sets publishable key if provided
  runApp(const BaithutApp());
}

class BaithutApp extends StatelessWidget {
  const BaithutApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()..init()),
      ],
      child: MaterialApp(
        title: 'Baithut',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
          useMaterial3: true,
        ),
        home: const RootGate(),
      ),
    );
  }
}

class RootGate extends StatelessWidget {
  const RootGate({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthService>(builder: (_, auth, __) {
      if (auth.initializing) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      return auth.user == null ? const LoginScreen() : const HomeScreen();
    });
  }
}
