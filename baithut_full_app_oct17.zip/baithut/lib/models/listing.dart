import 'package:cloud_firestore/cloud_firestore.dart';
class Listing {
  final String? id;
  final String title;
  final String brand;
  final String condition; // New, Like New, Used
  final int priceCents;
  final String sellerId;
  final bool verified;
  final bool sold;
  final List<String> images;
  final DateTime createdAt;

  Listing({
    this.id,
    required this.title,
    required this.brand,
    required this.condition,
    required this.priceCents,
    required this.sellerId,
    this.verified = false,
    this.sold = false,
    this.images = const [],
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  factory Listing.fromJson(Map<String, dynamic> json) {
    return Listing(
      id: json['id'],
      title: json['title'] ?? '',
      brand: json['brand'] ?? '',
      condition: json['condition'] ?? 'Used',
      priceCents: json['priceCents'] ?? 0,
      sellerId: json['sellerId'] ?? '',
      verified: json['verified'] ?? false,
      sold: json['sold'] ?? false,
      images: (json['images'] as List?)?.map((e) => e.toString()).toList() ?? [],
      createdAt: (json['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() => {
    'title': title,
    'brand': brand,
    'condition': condition,
    'priceCents': priceCents,
    'sellerId': sellerId,
    'verified': verified,
    'sold': sold,
    'images': images,
    'createdAt': createdAt,
  };
}
