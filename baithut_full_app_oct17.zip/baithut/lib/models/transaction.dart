class Transaction {
  final String buyerId;
  final String sellerId;
  final String listingId;
  final String status; // pending, verified, released, refunded
  final String? paymentIntentId;
  final DateTime createdAt;

  Transaction({
    required this.buyerId,
    required this.sellerId,
    required this.listingId,
    this.status = 'pending',
    this.paymentIntentId,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'buyerId': buyerId,
    'sellerId': sellerId,
    'listingId': listingId,
    'status': status,
    'paymentIntentId': paymentIntentId,
    'createdAt': createdAt,
  };
}
