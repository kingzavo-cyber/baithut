class AppUser {
  final String uid;
  final String? displayName;
  final String? email;
  final double rating;
  final bool verified;

  AppUser({required this.uid, this.displayName, this.email, this.rating = 5.0, this.verified = false});

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      uid: json['uid'],
      displayName: json['displayName'],
      email: json['email'],
      rating: (json['rating'] ?? 5.0) * 1.0,
      verified: json['verified'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
    'uid': uid,
    'displayName': displayName,
    'email': email,
    'rating': rating,
    'verified': verified,
  };
}
