import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

class StorageService {
  static final _storage = FirebaseStorage.instance;

  static Future<String> uploadListingImage(String listingId, File file) async {
    final ref = _storage.ref().child('listings').child(listingId).child(DateTime.now().millisecondsSinceEpoch.toString());
    final snap = await ref.putFile(file);
    return await snap.ref.getDownloadURL();
  }
}
