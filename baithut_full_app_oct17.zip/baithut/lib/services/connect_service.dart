import 'dart:convert';
import 'package:http/http.dart' as http;

class ConnectService {
  final String baseUrl;
  ConnectService(this.baseUrl);

  /// Creates or fetches a connected account for the current user (server-side links to auth uid).
  Future<Map<String, dynamic>> createOrGetAccount() async {
    final res = await http.post(Uri.parse('$baseUrl/createOrGetAccount'));
    if (res.statusCode != 200) throw Exception(res.body);
    return Map<String, dynamic>.from(jsonDecode(res.body));
  }

  /// Generates an onboarding link for Express account setup.
  Future<String> createAccountLink() async {
    final res = await http.post(Uri.parse('$baseUrl/createAccountLink'));
    if (res.statusCode != 200) throw Exception(res.body);
    final data = Map<String, dynamic>.from(jsonDecode(res.body));
    return data['url'] as String;
  }
}
