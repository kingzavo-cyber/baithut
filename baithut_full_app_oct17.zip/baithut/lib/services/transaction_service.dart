import 'package:cloud_firestore/cloud_firestore.dart';

class TransactionService {
  static final _db = FirebaseFirestore.instance;

  static Future<String> create({
    required String buyerId,
    required String sellerId,
    required String listingId,
    required String paymentIntentId,
    required int baseAmountCents,
    required int totalChargeCents,
  }) async {
    final ref = await _db.collection('transactions').add({
      'buyerId': buyerId,
      'sellerId': sellerId,
      'listingId': listingId,
      'paymentIntentId': paymentIntentId,
      'baseAmountCents': baseAmountCents,
      'totalChargeCents': totalChargeCents,
      'status': 'paid',
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  static Future<void> updateStatus(String transactionId, String status, {Map<String, dynamic>? extra}) async {
    await _db.collection('transactions').doc(transactionId).set({
      'status': status,
      if (extra != null) ...extra,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  static Future<Map<String, dynamic>?> findLatestByListing(String listingId) async {
    final q = await _db.collection('transactions')
      .where('listingId', isEqualTo: listingId)
      .orderBy('createdAt', descending: true)
      .limit(1).get();
    if (q.docs.isEmpty) return null;
    final d = q.docs.first;
    final data = d.data();
    data['id'] = d.id;
    return data;
  }
}
