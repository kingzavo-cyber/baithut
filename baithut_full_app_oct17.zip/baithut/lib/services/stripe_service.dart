import 'package:flutter_stripe/flutter_stripe.dart';

class StripeService {
  static void init() {
    // TODO: replace with your Stripe publishable key
    const publishableKey = String.fromEnvironment('STRIPE_PUBLISHABLE_KEY', defaultValue: '');
    if (publishableKey.isNotEmpty) {
      Stripe.publishableKey = publishableKey;
      Stripe.merchantIdentifier = 'merchant.com.baithut.app';
    }
  }
}
