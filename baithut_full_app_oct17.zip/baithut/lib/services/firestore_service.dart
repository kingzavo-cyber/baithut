import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/listing.dart';
import '../models/transaction.dart' as tx;

class FirestoreService {
  static final _db = FirebaseFirestore.instance;

  static Stream<List<Listing>> streamListings() {
    return _db.collection('listings')
      .where('sold', isEqualTo: false)
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map((d) => Listing.fromJson({...d.data(), 'id': d.id})).toList());
  }

  static Future<void> createListing(Listing l) async {
    await _db.collection('listings').add(l.toJson());
  }

  static Future<void> markSold(String listingId) async {
    await _db.collection('listings').doc(listingId).update({'sold': true});
  }

  static Future<void> createTransaction(tx.Transaction t) async {
    await _db.collection('transactions').add(t.toJson());
  }
}
